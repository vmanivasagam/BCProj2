'use strict';
const irecordcontract = require('./precordcontract.js');
module.exports.contracts = [irecordcontract];
